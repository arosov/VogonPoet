
uv run --index https://download.pytorch.org/whl/cu121 --with-requirements requirements_stt.txt --with RealtimeSTT python run_stt.py
