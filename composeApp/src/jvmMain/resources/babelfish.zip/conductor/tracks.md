# Tracks Registry

---

- [x] **Track: Establish the core audio pipeline using parakeet-stream with a modular, uv-runnable architecture.**
*Link: [./tracks/streaming_foundation_20260207/](./tracks/streaming_foundation_20260207/)*

---

- [x] **Track: Rework startup sequence (Hardware -> Config -> Server -> Pipeline)**
*Link: [./tracks/startup_rework_20260209/](./tracks/startup_rework_20260209/)*
