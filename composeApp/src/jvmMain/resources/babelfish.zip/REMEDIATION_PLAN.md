# Babelfish Remediation & Optimization Plan

This document outlines the steps to address stability issues, latency bottlenecks, and technical debt identified during the project review.

## Phase 1: Architecture & Stability (Critical)
- [ ] **Fix WakeWord Deadlock**: Replace `threading.Lock` with `threading.RLock` in `WakeWordEngine` to allow re-entrant calls during reconfiguration.
- [ ] **Hotkey Manager Cleanup**: Remove duplicate method definitions in `hotkey_manager.py` and ensure consistent use of `pipeline.request_mode`.
- [ ] **Pipeline Thread Safety**: Add a `threading.Lock` to the `Pipeline` class to protect state variables (`is_idle`, `pending_idle`) from race conditions across STT, WebSocket, and Hotkey threads.
- [ ] **Non-Blocking Server Updates**: Wrap heavy configuration propagation (especially model loading) in `asyncio.to_thread` to prevent freezing the WebSocket event loop.

## Phase 2: Latency & Performance (Optimization)
- [ ] **Audio Callback Optimization**: Move `soxr.resample` out of the high-priority `_audio_callback` and into the generator loop to prevent audio dropouts.
- [ ] **Buffer Efficiency**: Reduce `np.concatenate` frequency. Use more efficient structures for accumulating audio chunks.
- [ ] **Asynchronous Transcription**: Offload `engine.transcribe` calls to a thread pool to prevent blocking the VAD and main STT loop.
- [ ] **Bounded Queues**: Set a maximum size for `audio_queue` in `AudioStreamer` to prevent OOM in case of pipeline stalls.

## Phase 3: Cleanup & Refactoring
- [ ] **Legacy File Removal**: Delete `run_stt.py`, `requirements_stt.txt`, `models_config.py`, and `whisper_vram_usage.md`.
- [ ] **Config Registration**: Refactor `ConfigManager` to use a protocol/metadata-based registration instead of brittle `isinstance` checks.
- [ ] **Dead Code Removal**: Remove `HistoryBuffer` from `audio.py`.
- [ ] **State Machine Consolidation**: Centralize pipeline state management into a formal State Machine/Enum.
