#!/bin/bash
uv run python scripts/generate_schema.py
